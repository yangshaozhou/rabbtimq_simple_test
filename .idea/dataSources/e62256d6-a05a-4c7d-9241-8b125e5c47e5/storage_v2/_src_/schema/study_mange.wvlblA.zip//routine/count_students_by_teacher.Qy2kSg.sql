create
    definer = root@`%` procedure count_students_by_teacher(IN teacher_id int, OUT student_count int)
BEGIN
    SELECT COUNT(DISTINCT student_id) INTO student_count
    FROM course
             INNER JOIN student_course ON course.id = student_course.course_id
    WHERE course.teacher_id = teacher_id;
END;

