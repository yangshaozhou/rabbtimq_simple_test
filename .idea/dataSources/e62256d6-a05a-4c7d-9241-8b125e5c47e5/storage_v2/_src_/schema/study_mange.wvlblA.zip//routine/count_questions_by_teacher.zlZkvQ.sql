create
    definer = root@`%` procedure count_questions_by_teacher(IN teacher_id int, OUT question_count int)
BEGIN
    SELECT COUNT(*) INTO question_count FROM question WHERE question.teacher_id = teacher_id;
END;

