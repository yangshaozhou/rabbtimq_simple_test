create
    definer = root@`%` procedure count_correct_answers_by_question(IN question_id int, OUT correct_count int)
BEGIN
    SELECT COUNT(*) INTO correct_count
    FROM student_question
    WHERE student_question.question_id = question_id AND is_correct = 1;
END;

