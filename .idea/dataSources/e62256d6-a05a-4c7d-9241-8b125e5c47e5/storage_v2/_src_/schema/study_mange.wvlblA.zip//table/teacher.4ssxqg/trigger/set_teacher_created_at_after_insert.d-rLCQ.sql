create definer = root@`%` trigger set_teacher_created_at_after_insert
    before insert
    on teacher
    for each row
BEGIN
    SET NEW.create_time = NOW();
END;

