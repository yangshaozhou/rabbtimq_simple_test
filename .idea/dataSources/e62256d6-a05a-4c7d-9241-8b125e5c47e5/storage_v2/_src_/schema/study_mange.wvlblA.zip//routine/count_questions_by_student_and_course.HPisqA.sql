create
    definer = root@`%` procedure count_questions_by_student_and_course(IN student_id int, IN course_id int, OUT question_count int)
BEGIN
    SELECT COUNT(*) INTO question_count
    FROM student_question
    WHERE student_id = student_question.student_id AND student_question.course_id = course_id;
END;

