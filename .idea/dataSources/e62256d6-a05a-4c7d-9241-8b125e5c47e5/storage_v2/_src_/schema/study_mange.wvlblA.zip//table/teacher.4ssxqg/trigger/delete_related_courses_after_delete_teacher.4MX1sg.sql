create definer = root@`%` trigger delete_related_courses_after_delete_teacher
    after delete
    on teacher
    for each row
BEGIN
    DELETE FROM course
    WHERE teacher_id = OLD.id;
END;

